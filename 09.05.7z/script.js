function szamol(){
    let kapacitas = document.getElementById("kapacitas").value;
    let Kap = document.getElementById("Kap").value;
    let sebessegSlider = document.getElementById("sebessegSlider").value;
    let AtvSeb = document.getElementById("AtvSeb").value;

    if (Kap="GB"){
        kapacitas*=1000;
    }
    else if (Kap="TB"){
        kapacitas*=1000000;
    }

    if (AtvSeb="GBps"){
        sebessegSlider*=1000;
    }
    else if (AtvSeb="KBps"){
        sebessegSlider/=1000;
    }
    else if (AtvSeb="Mbps"){
        sebessegSlider/=8;
    }

    let eredmeny = kapacitas/sebessegSlider;
    document.getElementById("eredmeny").innerHTML=eredmeny;
}
function kiir(){
    let slider = document.getElementById("sebessegSlider").value;
    let output= document.getElementById("jelenlegiSeb");
    output.innerHTML = slider;
}

